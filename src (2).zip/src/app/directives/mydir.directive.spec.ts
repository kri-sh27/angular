import { MydirDirective } from './mydir.directive';

describe('MydirDirective', () => {
  it('should create an instance', () => {
    const directive = new MydirDirective();
    expect(directive).toBeTruthy();
  });
});
