import { PhdirDirective } from './phdir.directive';

describe('PhdirDirective', () => {
  it('should create an instance', () => {
    const directive = new PhdirDirective();
    expect(directive).toBeTruthy();
  });
});
